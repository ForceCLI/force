@isTest
private class <%= apiName %> {

}